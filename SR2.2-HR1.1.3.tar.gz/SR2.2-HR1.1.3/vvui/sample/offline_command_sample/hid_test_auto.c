/*******************************************************
 This contents of this file may be used by anyone
 for any reason without any conditions and may be
 used as a starting point for your own applications
 which use HIDAPI.
********************************************************/
#include "user_interface.h"
int once_awake = 0;

int business_proc_callback(business_msg_t businessMsg)
{
	int res = 0;
	char fileName[] = DENOISE_SOUND_PATH;
	char fileName_ori[] = ORIGINAL_SOUND_PATH;
	static int index = 0;
	unsigned char buf[4096];
	switch (businessMsg.modId)
	{
	case 0x01:
		if (businessMsg.msgId == 0x01)
		{
			unsigned char key[] = "errcode";
			int status = whether_set_succeed(businessMsg.data, key);
			if (status == 0)
			{
				//printf(">>>>>您已开启录音\n");
			}
		}
		else if (businessMsg.msgId == 0x02)
		{
			char fileName[] = DENOISE_SOUND_PATH;
			get_denoised_sound(fileName, businessMsg.data);
		}
		else if (businessMsg.msgId == 0x03)
		{
			unsigned char key[] = "errcode";
			int status = whether_set_succeed(businessMsg.data, key);
			if (status == 0)
			{
				//printf(">>>>>您已停止录音\n");
			}
		}
		else if (businessMsg.msgId == 0x04)
		{
			unsigned char key[] = "errcode";
			int status = whether_set_succeed(businessMsg.data, key);
			if (status == 0)
			{
				printf(">>>>>开/关原始音频成功\n");
			}
		}
		else if (businessMsg.msgId == 0x05)
		{
			unsigned char key[] = "errcode";
			int status = whether_set_succeed(businessMsg.data, key);
			if (status == 0)
			{
				printf(">>>>>设置主麦克风和灯光成功,新版本已去除建议更换接口\n");
			}
		}
		else if (businessMsg.msgId == 0x06)
		{
			char fileName_ori[] = ORIGINAL_SOUND_PATH;
			get_original_sound(fileName_ori, businessMsg.data);
		}
		else if (businessMsg.msgId == 0x07)
		{
			unsigned char key2[] = "beam";
			int major_id = whether_set_succeed(businessMsg.data, key2);
			major_mic_id = major_id;
			printf(">>>>>主麦克风id为%d号麦克风\n", major_mic_id);
		}
		else if (businessMsg.msgId == 0x08)
		{
			unsigned char key[] = "errcode";
			int status = whether_set_succeed(businessMsg.data, key);
			if (status == 0)
			{
				printf("\n>>>>>设置主麦克风成功\n");
			}
		}
		else if (businessMsg.msgId == 0x09)
		{
			unsigned char key[] = "errcode";
			int status = whether_set_succeed(businessMsg.data, key);
			if (status == 0)
			{
				printf("\n>>>>>设置灯光成功\n");
			}
		}
		break;
	case 0x02:
		if (businessMsg.msgId == 0x01)
		{
			unsigned char key1[] = "beam";
			unsigned char key2[] = "angle";
			major_mic_id = get_awake_mic_id(businessMsg.data, key1);
			mic_angle = get_awake_mic_angle(businessMsg.data, key2);
			if (major_mic_id <= 5 && major_mic_id >= 0 && mic_angle <= 360 && mic_angle >= 0)
			{
				if_awake = 1;
				led_id = get_led_based_angle(mic_angle);
				int ret1 = set_major_mic_id(major_mic_id);
				int ret2 = set_target_led_on(led_id);
				if (ret1 == 0 && ret2 == 0)
				{
					printf("\n>>>>>第%d个麦克风被唤醒\n", major_mic_id);
					printf("\n>>>>>唤醒角度为:%d\n", mic_angle);
					printf("\n>>>>>已点亮%d灯\n", led_id);
				}
			}
		}
		else if (businessMsg.msgId == 0x08)
		{
			unsigned char key1[] = "errstring";
			int result = whether_set_awake_word(businessMsg.data, key1);
			if (result == 0)
			{
				printf("\n>>>>>唤醒词设置成功 \n");
			}
			else if (result == -2)
			{
				printf("\n>>>>>唤醒词设置失败 \n");
			}
		}

		break;
	case 0x03:
		if (businessMsg.msgId == 0x01)
		{
			unsigned char key[] = "status";
			int status = whether_set_succeed(businessMsg.data, key);
			char protocol_version[40]; 
			int ret = get_protocol_version(businessMsg.data,protocol_version);
			printf(">>>>>麦克风%s,软件版本为:%s,协议版本为:%s\n", (status == 0 ? "正常工作" : "正在启动"),get_software_version(),protocol_version);
			if (status == 1)
			{
				char *fileName = SYSTEM_CONFIG_PATH;
				send_resource_info(fileName, 0);
			}
			else
			{
				is_boot = 1;
			}
		}

		break;

	case 0x04:
		if (businessMsg.msgId == 0x01)
		{
			whether_set_resource_info(businessMsg.data);
		}
		else if (businessMsg.msgId == 0x03) //文件接收结果
		{
			whether_set_resource_info(businessMsg.data);
		}
		else if (businessMsg.msgId == 0x04) //查看设备升级结果
		{
			whether_upgrade_succeed(businessMsg.data);
		}
		else if (businessMsg.msgId == 0x05) //下发文件
		{
			char fileName[] = SYSTEM_PATH;
			send_resource(businessMsg.data, fileName, 1);
		}
		else if (businessMsg.msgId == 0x08) //获取升级配置文件
		{
			printf("config.json: %s", businessMsg.data);
		}
		break;

	default:
		break;
	}
	return 0;
}

/********************获取识别到的内容里关键词、置信度以及关键词的id******************/
Effective_Result show_result(const char *string, const int input_confidence)
{
	Effective_Result current;
	int confidence_int = 0;
	int order_id = 0;

	if (strlen(string) > 250)
	{
		char asr_result[32];	//识别到的关键字的结果
		char asr_confidence[3]; //识别到的关键字的置信度
		char str_orderID[8];	//识别到的关键字的id

		char *p1 = strstr(string, "<rawtext>");
		char *p2 = strstr(string, "</rawtext>");
		int n1 = p1 - string + 1;
		int n2 = p2 - string + 1;

		char *p3 = strstr(string, "<confidence>");
		char *p4 = strstr(string, "</confidence>");
		int n3 = p3 - string + 1;
		int n4 = p4 - string + 1;
		for (int i = 0; i < 32; i++)
		{
			asr_result[i] = '\0';
		}

		strncpy(asr_confidence, string + n3 + strlen("<confidence>") - 1, n4 - n3 - strlen("<confidence>"));
		asr_confidence[n4 - n3 - strlen("<confidence>")] = '\0';
		confidence_int = atoi(asr_confidence);

		if (confidence_int >= input_confidence)
		{
			strncpy(asr_result, string + n1 + strlen("<rawtext>") - 1, n2 - n1 - strlen("<rawtext>"));
			asr_result[n2 - n1 - strlen("<rawtext>")] = '\0'; //加上字符串结束符。

			memset(str_orderID, 0, sizeof(str_orderID));
			char *str_todo = strstr(p3, "id=");
			char *str_todo_back = strstr(str_todo, ">");
			strncpy(str_orderID, str_todo + 4, str_todo_back - str_todo - 5);
			order_id = atoi(str_orderID);
		}
		else
		{
			strncpy(asr_result, "", 0);
			order_id = 0;
		}

		current.effective_confidence = confidence_int;
		strcpy(current.effective_word, asr_result);
		current.effective_id = order_id;
		return current;
	}
	else
	{
		current.effective_confidence = 0;
		strcpy(current.effective_word, " ");
		current.effective_id = 0;
		return current;
	}
}

/****************本函数是一个样例，根据关键词内容或id，进行其他操作*******************/
void control_jetbot(const char *judge_type, const char *data)
{
	if (!strcmp(data, "左转") || !strcmp(data, "往左转") || !strcmp(data, "向左转"))
	{
		printf(">>>>>执行运动指令中，小车正在左转\n");
	}
	else if (!strcmp(data, "右转") || !strcmp(data, "往右转") || !strcmp(data, "向右转"))
	{
		printf(">>>>>执行运动指令中，小车正在右转\n");
	}
	else if (!strcmp(data, "往前走") || !strcmp(data, "向前走") || !strcmp(data, "向前"))
	{
		printf(">>>>>执行运动指令中，小车正在向前走\n");
	}
	else if (!strcmp(data, "往后走") || !strcmp(data, "向后走") || !strcmp(data, "向后"))
	{
		printf(">>>>>执行运动指令中，小车正在向后走\n");
	}
	else if (!strcmp(data, "左走") || !strcmp(data, "往左走") || !strcmp(data, "向左走"))
	{
		printf(">>>>>执行运动指令中，小车正在往左走\n");
	}
	else if (!strcmp(data, "右走") || !strcmp(data, "往右走") || !strcmp(data, "向右走"))
	{
		printf(">>>>>执行运动指令中，小车正在往右走\n");
	}
}

int main(int argc, char *argv[])
{
	hid_device *handle;
	handle = hid_open();
	if (mic_open_status!=0)
	{
		printf(">>>>>无法打开麦克风设备，尝试重新插拔进行测试\n");
		return -1;
	}
	printf(">>>>>成功打开麦克风设备\n");
	protocol_proc_init(send_to_usb_device, recv_from_usb_device, business_proc_callback, err_proc);
	get_system_status();
	sleep(1);
	if (!is_boot)
	{
		printf(">>>>>开机中，请稍等！\n");
	}
	while (!is_boot)
	{
		if (is_reboot)
		{
			break;
		}
	}
	printf(">>>>>开机成功！\n");
	
	while (1)
	{
		if (!if_awake)
		{
			printf(">>>>>待唤醒，请用唤醒词进行唤醒！\n");
		}
		while (!if_awake)
		{
			once_awake = awake_count;
			sleep(1);
		}
		printf(">>>>>唤醒成功，已开启录音！\n");

		while (once_awake > 0)
		{
			once_awake--;
			const char file1[] = DENOISE_SOUND_PATH;
			remove(file1);
			start_to_record_denoised_sound();
			int time_per = time_per_order;
			while (time_per--)
			{
				sleep(1);
			}
			finish_to_record_denoised_sound();
			unsigned char file[] = DENOISE_SOUND_PATH;

			Recognise_Result result = deal_with(file, ASR_RES_PATH, GRM_BUILD_PATH, GRM_FILE, LEX_NAME);
			if (result.whether_recognised)
			{
				printf(">>>>>是否识别成功:　[ %s ]\n", "是");
				if (result.whole_content)
				{
					/**为了在终端可视化方便,可将本行注释，若需查看完整反馈，可解除屏蔽**/
					printf(">>>>>全部返回结果:　[ %s ]\n", result.whole_content);
					Effective_Result effective_ans = show_result(result.whole_content, confidence); //
					printf(">>>>>关键字的置信度: [ %d ]\n", effective_ans.effective_confidence);
					if (effective_ans.effective_confidence >= confidence) //如果大于置信度阈值则进行显示或者其他控制操作
					{
						printf(">>>>>关键字识别结果: [ %s ]\n", effective_ans.effective_word);
						control_jetbot("word", effective_ans.effective_word);
					}
					else
					{
						printf(">>>>>关键字置信度较低，文本不予显示\n");
					}
				}
				else
				{
					printf(">>>>>未能检测到有效声音,请重试\n");
				}
			}
			else
			{
				printf(">>>>>是否识别成功:　[ %s ]\n", "否");
				printf(">>>>>错误原因: [ %s ]\n", result.fail_reason);
			}

			sleep(1);
		}
		if_awake = 0;
	}
	finish_to_record_denoised_sound();
	finish_to_record_original_sound();
	sleep(1);
	hid_close();
	return 0;
}
