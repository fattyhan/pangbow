#!/bin/bash
sudo apt install -y build-essential
sudo apt install -y automake
sudo apt install -y libdotconf-dev
sudo apt install -y libglib2.0-dev
sudo apt install -y libpulse-dev
./autogen.sh && ./configure && make && sudo make install

