/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef LIBMUSICXML_PRIVATE_H
#define LIBMUSICXML_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"2.0.0.2"
#define VER_MAJOR	2
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	2
#define COMPANY_NAME	"Grame"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"C++ library to support MusicXML"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"(c) Grame 2007"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"libmusicxml"
#define PRODUCT_NAME	"libmusicxml"
#define PRODUCT_VERSION	"2.0.0"

#endif /*LIBMUSICXML_PRIVATE_H*/
