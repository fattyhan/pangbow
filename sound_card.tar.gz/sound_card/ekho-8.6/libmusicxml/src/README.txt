----------------------------------------------------------------------------

   MusicXML library version 2

----------------------------------------------------------------------------

  This library is free software; you can redistribute it and/or
  modify it under the terms of the Mozilla Public License Version 2.0.

  Grame Research Laboratory, 11 cours de Verdun - Gensoul 69002 Lyon - France
  research@grame.fr


----------------------------------------------------------------------------
